from django.contrib import admin
from . models import employees
# Register your models here.

admin.site.register(employees)

